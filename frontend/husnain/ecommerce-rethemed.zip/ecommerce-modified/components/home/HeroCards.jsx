import React from "react";
import CardSwap, { Card } from '../ui/CardSwap';
import Image from "next/image";

const HeroCards = () => {
  const cards = [
    { src: "/hero/hero1.jpg", label: "New Arrivals", tag: "Fall 2025" },
    { src: "/hero/hero2.jpg", label: "Kids Collection", tag: "Ages 2–14" },
    { src: "/hero/hero3.jpg", label: "Essentials", tag: "All Season" },
  ];

  return (
    <div className="h-full w-full">
      <CardSwap
        width="110%"
        height="auto"
        cardDistance={60}
        verticalDistance={70}
        delay={5000}
        pauseOnHover={false}
      >
        {cards.map(({ src, label, tag }) => (
          <Card key={label}>
            <div className="relative">
              <div className="absolute top-3 left-3 z-10 flex gap-2">
                <span className="bg-white/90 text-slate-800 font-bold text-xs px-2 py-1 rounded-full">{label}</span>
                <span className="bg-amber-500 text-white font-mono text-xs px-2 py-1 rounded-full">{tag}</span>
              </div>
              <Image
                src={src}
                alt={label}
                width={800}
                height={500}
                sizes="(max-width: 768px) 100vw, 800px"
                loading="lazy"
                className="rounded-lg"
              />
            </div>
          </Card>
        ))}
      </CardSwap>
    </div>
  );
};

export default HeroCards;
