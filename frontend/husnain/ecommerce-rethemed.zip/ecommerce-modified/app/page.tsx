import Navbar from "@/components/Navbar";
import HeroSection from "@/components/home/HeroSection";
import MarqueeSection from "@/components/home/MarqueeSection";
import BentoGrid from "@/components/home/BentoGrid";
import StatementSection from "@/components/home/StatementSection";
import NewArrival from "@/components/home/NewArrivals";
import AmazingPicks from "@/components/home/AmazingPicks";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <HeroSection />
      <MarqueeSection />
      <BentoGrid />
      <NewArrival />
      <AmazingPicks />
      <StatementSection />
      <Footer />
    </>
  );
}
